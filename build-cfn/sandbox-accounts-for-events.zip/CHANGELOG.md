# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2022-06-10
### Added
- Initial release.

### Changed
- no changed.

### Removed
- nothing removed.


[1.0.0]: https://github.com/olivierlacan/keep-a-changelog/compare/v0.3.0...v1.0.0
