#!/bin/bash
# This script is executed before every execution of AWS Nuke (via CodeBuild reset account job).
# It provides the opportunity to perform so manual cleanup stuff before AWS Nuke is executed.

echo "Executing pre-cleanup script"


